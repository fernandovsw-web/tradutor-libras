import csv
import os
from collections import Counter

import joblib
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split

ARQUIVO_DADOS = os.path.join("dados", "pontos.csv")
ARQUIVO_MODELO = os.path.join("modelo", "modelo_letras.joblib")

# 1. Ler o CSV: primeira coluna = letra, o resto = os 63 números
X, y = [], []
with open(ARQUIVO_DADOS) as arquivo:
    for linha in csv.reader(arquivo):
        y.append(linha[0])
        X.append([float(v) for v in linha[1:]])

X = np.array(X)
y = np.array(y)

print("Amostras por letra:")
for letra, qtd in sorted(Counter(y).items()):
    print(f"  {letra}: {qtd}")

# 2. Separar 80% para treinar e 20% para testar
X_treino, X_teste, y_treino, y_teste = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# 3. Treinar e avaliar
modelo = RandomForestClassifier(n_estimators=200, random_state=42)
modelo.fit(X_treino, y_treino)

previsoes = modelo.predict(X_teste)
print(f"\nAcuracia no teste: {accuracy_score(y_teste, previsoes):.1%}")
print(classification_report(y_teste, previsoes))

# ATENÇÃO: frames gravados em sequência são muito parecidos entre si, então
# esse número tende a sair perto de 100% e é otimista demais. O teste de
# verdade é o reconhecimento em tempo real (próxima etapa).

# 4. Treinar de novo com TODOS os dados e salvar o modelo final
modelo.fit(X, y)
os.makedirs("modelo", exist_ok=True)
joblib.dump(modelo, ARQUIVO_MODELO)
print(f"\nModelo salvo em {ARQUIVO_MODELO}")
