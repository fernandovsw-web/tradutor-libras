import numpy as np


def normalizar(mao):
    """Recebe a mão detectada pelo MediaPipe e devolve 63 números normalizados.

    Por que normalizar? Sem isso, o modelo aprenderia a posição da mão na tela
    e o tamanho dela, e não o formato do sinal. Fazendo duas coisas:
      1. Subtrai o pulso (ponto 0) de todos os pontos: a mão passa a ser
         descrita em relação ao pulso, não à tela.
      2. Divide pelo maior valor: a mão fica na mesma escala, perto ou longe
         da câmera.
    """
    pontos = np.array([[p.x, p.y, p.z] for p in mao.landmark])  # 21 linhas x 3 colunas
    pontos = pontos - pontos[0]  # relativo ao pulso

    maior = np.max(np.abs(pontos))
    if maior > 0:
        pontos = pontos / maior

    return pontos.flatten()  # 63 números
